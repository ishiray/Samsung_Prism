import React from "react";
import Grid from "../components/Grid/Grid";

function SIM() {
  console.log("SIM");
  
  return <Grid text="SIM" />;

  
}

export default SIM;
