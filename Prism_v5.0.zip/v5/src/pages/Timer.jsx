import React from "react";
import Grid from "../components/Grid/Grid";

function Timer() {
  console.log("Timer");

  return <Grid text="Timer" />;
}

export default Timer;
