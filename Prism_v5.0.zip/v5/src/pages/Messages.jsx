import React from "react";
import Grid from "../components/Grid/Grid";

function Messages() {
  console.log("Messages");

  return <Grid text="Messages" />;
}

export default Messages;
