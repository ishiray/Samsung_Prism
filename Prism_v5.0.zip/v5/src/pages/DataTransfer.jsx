import React from "react";
import Grid from "../components/Grid/Grid";

function DataTransfer() {
  console.log("DataTransfer");

  return <Grid text="Data Transfer" />;
}

export default DataTransfer;
