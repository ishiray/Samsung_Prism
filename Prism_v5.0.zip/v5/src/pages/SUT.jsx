import React from "react";
import Workspace from "../components/Workspace/workspace";
export var txt = "HOME";
function SUT() {
  console.log("SUT");
  
  // return <Grid text="SUT" />;
          
        
  
  
  
}

export default SUT;
