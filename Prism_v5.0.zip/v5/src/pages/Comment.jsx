import React from "react";
import Grid from "../components/Grid/Grid";

function Comment() {
  console.log("Comment");

  return <Grid text="Comment" />;
}

export default Comment;
