import React from "react";
import Grid from "../components/Grid/Grid";

function Analyzer() {
  console.log("Analyzer");

  return <Grid text="Analyzer" />;
}

export default Analyzer;
