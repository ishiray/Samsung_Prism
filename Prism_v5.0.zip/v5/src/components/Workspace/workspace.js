import React, { useState } from 'react'
import background from "../Grid/grid.jpeg"


function Workspace() {
    
    return (
        
            <div style={{marginLeft: "10rem"}}>
                 <div style = {{ backgroundColor: "black", height: "36.5rem", width: "52rem", backgroundImage: `url(${background})` }} >
                 

                 </div>
            </div>
               
           
    );
}



export default Workspace;


  
 
