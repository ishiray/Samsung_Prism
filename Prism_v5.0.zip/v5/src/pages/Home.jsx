import React from "react";
import Grid from "../components/Grid/Grid";

function Home() {
  console.log("DataTransfer");

  return( <div style={{marginLeft: "0rem"}}>
  <div style = {{ backgroundColor: "lightgray", height: "36.5rem", width: "70rem"}} >
  

  </div>
</div>
  );
}

export default Home;