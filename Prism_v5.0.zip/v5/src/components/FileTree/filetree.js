import React, { useState } from "react";
import FolderTree from "./FolderTree";
import "../../styles.css";
import Button from "react-bootstrap/Button";



//*****************************************
function FileTree() {
  const [data, setData] = useState({});
    const [newDir, setNewDir] = useState(true);
    const [formData, setFormData] = useState({
    name: ''
  });

  async function getDirContents(DirData, currStruct = null) {
    function createNode(name, isFolder) {
      return {
        name: name,
        // handle: filesystemfilehandle,
        //type:isFolder? "folder": String(fileHandle.type).split("/")[0],
        type: isFolder ? "folder" : "text/plain",
        folder: isFolder,
        toggled: true,
        children: []
      };
    }

    try {
      if (currStruct === null) {
        currStruct = createNode(DirData.pathHead, true);
      }

      let DirFolders = await DirData.folders;
      let DirtextFiles = await DirData.textFiles;

      for await (const dir of DirFolders) {
        let folderNode = createNode(dir, true);
        currStruct.children.push(folderNode);
      }

      for await (const fil of DirtextFiles) {
        let fileNode = createNode(fil, false);
        currStruct.children.push(fileNode);
      }

      console.log("done with loop and this is the output");
      console.log(JSON.stringify(currStruct));
      return currStruct;
    } catch (err) {
      console.error(err);
    }
  }

  async function getDirData() {
    try {
      const response = await fetch(
        "http://192.168.0.218:3000/get-directory-contents"
      );
      if (response.status === 200) {
        const DirData = await response.json();
        console.log(DirData);
        let theData = await getDirContents(DirData);
        setData(theData);
        console.log(data);
      } else {
        alert("failed to get dirctory data");
      }
    } catch (err) {
      console.error(err);
    }
  }

    function toggleNewDir() {
    setNewDir(!newDir);
  }

  function newDirCreated(){
    toggleNewDir();
    getDirData();
    return false;
  }

//************************** */

 const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Send the POST request using fetch or axios
    fetch('http://192.168.0.218:3000/create-new-user-directory', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    })
      .then((response) => response.json())
      .then((data) => {
        // Handle the response data if needed
        newDirCreated();
        console.log(data);
      })
      .catch((error) => {
        // Handle any errors that occurred during the fetch
        console.error('Error:', error);
      });
  };







//******************* */
  return (
    <>
      <div className="filetree">
        <div>
          {/* <label htmlFor="fileInput">Choose a Folder:</label> */}
          <Button
            variant="outline-dark"
            onClick={getDirData}
            style={{
              height: "4%",
              margin: 0,
              marginLeft: "2%",
              fontSize: "14px",
              padding: 0
            }}
          >
            Show
          </Button>

          <div
          style={{
            display:"flex",
            alignContent:"centre",
            marginTop:"1%"
          }}>
           
           <Button
            variant="outline-dark"
            onClick={toggleNewDir}
            style={{
              height: "4%",
              margin: 0,
              marginLeft: "2%",
              fontSize: "14px",
              padding: 0
            }}
          >
            New folder
          </Button>

          <Button
            variant="outline-dark"
            onClick={toggleNewDir}
            style={{
              height: "4%",
              margin: 0,
              marginLeft: "2%",
              fontSize: "14px",
              padding: 0
            }}
          >
            up
          </Button>
          </div>

          <div hidden={newDir}>
          <form onSubmit={handleSubmit}>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="folder name"
          style={{
            height:"2%",
            width:"50%",
            margin: "2%",
            padding: "0",
            borderRadius: "0px",
          }}
          required
        />
        <button type="submit"
        style={{
          height:"1%",
          marginLeft:"5%",
          width:"30%",
          backgroundColor:"grey",
          margin: '0rem 0',
          // padding: '0.25rem',
          borderWidth:"1px",
          borderColor:"black",
          borderRadius: '5px',
          color:"black"
        }}>create</button>
      </form>




          </div>
          {/*<button id="folder-select" onClick={requestFileSystemAccess} style={{ backgroundColor: '#919191' }}>click me</button>
           */}
        </div>
        <div>
          <FolderTree json={data} />
        </div>
      </div>
    </>
  );
}

//****************************************************************** */

// }

export default FileTree;
